const express = require('express')
const router = express.Router()
const multer = require('multer')
const multerConfig = require('./config/multer_config')
const upload = multer(multerConfig.config).single(multerConfig.keyUpload)


router.get('/', (req, res) => {
    res.send('Hello');
})

router.get('/CheckName/:id', (req, res) => {
    res.send('Get');
})

router.post('/CheckName/:id', (req, res) => {
    const id = req.file
    console.log(req.body)

    upload(req, res, (err) => {
        if (err instanceof multer.MulterError) {
            console.log(`error: ${JSON.stringify(err)}`)
        } else if (err) {
            console.log(`error: ${JSON.stringify(err)}`)
        }

        const filename = req.file ? req.file.fieldname : undefined
        res.send(`POST Chechname: ${req.params.id}, ${filename}`)
    })

})


module.exports = router